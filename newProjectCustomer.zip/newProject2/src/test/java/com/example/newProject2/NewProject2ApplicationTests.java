package com.example.newProject2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewProject2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
